import java.util.Scanner;
/**
 * Write a description of class Project1 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Project1{
    public static void main(String[]args){
        Scanner userInput= new Scanner(System.in);
        
        System.out.print("Enter the month, day and year: ");
        int month = userInput.nextInt();
        int day = userInput.nextInt();
        int year = userInput.nextInt();
        boolean passesValidation = true;
        boolean leapYear;
        int realDate;
        if (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0)){
            leapYear = true;
        }
        else{
            leapYear = false;
        }
        /*if (year<0 || year>2099){
            System.out.print("Invalid");
            passesValidation = false;
        }
        else{}*/
        String monthName = "";
        if (passesValidation){
            if (month>12 || month<0){
                System.out.println("Invalid month:" + month);
                passesValidation = false;
            }
            else{
                if (day == 1){
                    switch (month){
                        case 1 : monthName = "December";
                        break;
                        case 2 : monthName = "January";
                        break;
                        case 3 : monthName = "February";
                        break;
                        case 4 : monthName = "March";
                        break;
                        case 5 : monthName = "April";
                        break;
                        case 6 : monthName = "May";
                        break;
                        case 7 : monthName = "June";
                        break;
                        case 8 : monthName = "July";
                        break;
                        case 9 : monthName = "August";
                        break;
                        case 10 : monthName = "September";
                        break;
                        case 11 : monthName = "October";
                        break;
                        case 12 : monthName = "November";
                        break;
                    }
                }
                else{
                    switch(month){
                        case 1 : monthName = "January";
                        break;
                        case 2 : monthName = "February";
                        break;
                        case 3 : monthName = "March";
                        break;
                        case 4 : monthName = "April";
                        break;
                        case 5 : monthName = "May";
                        break;
                        case 6 : monthName = "June";
                        break;
                        case 7 : monthName = "July";
                        break;
                        case 8 : monthName = "August";
                        break;
                        case 9 : monthName = "September";
                        break;
                        case 10 : monthName = "October";
                        break;
                        case 11 : monthName = "November";
                        break;
                        case 12 : monthName = "December";
                        break;
                    }
                }
                //System.out.print(monthName);
            }
        }
        int date = 0;
        if (passesValidation){
            if (month==1){
                if (day >= 2 && day <= 30){
                    date = day - 1;
                }
                else if (day == 1){
                    date = 31;
                    year = year - 1;
                }
                else{
                    passesValidation = false;
                }
            }
            else if (month==2){
                if (leapYear){
                    if(day >= 2 && day <= 29){
                        date = day -1;
                    }
                    else if (day == 1){
                        date = 30;
                    }
                    else{
                        passesValidation = false;
                    }
                }
                else{
                    if(day >= 2 && day <= 28){
                        date = day - 1;
                    }
                    else if (day == 1){
                        date = 30;
                    }
                    else{
                        passesValidation = false;
                    }
                }
            }
            else if (month==3){
                if (leapYear){
                    if (day >= 2 && day <= 31){
                        date = day - 1;
                    }
                    else if (day == 1){
                        date = 29;
                    }
                    else{
                        passesValidation = false;
                    }
                }
                else {
                    if (day >= 2 && day <= 31){
                        date = day - 1;
                    }
                    else if (day == 1){
                        date = 28;
                    }
                    else{
                        passesValidation = false;
                    }
                }
            }
            else if (month==4){
                if (day >= 2 && day <= 30){
                    date = day - 1;
                }
                else if (day == 1){
                    date = 31;
                }
                else{
                    passesValidation = false;
                }
            }
            else if (month==5){
                if (day >= 2 && day <= 31){
                    date = day - 1;
                }
                else if (day == 1){
                    date = 30;
                }
                else{
                    passesValidation = false;
                }
            }
            else if (month==6){
                if (day >= 2 && day <= 30){
                    date = day - 1;
                }
                else if (day == 1){
                    date = 31;
                }
                else{
                    passesValidation = false;
                }
            }
            else if (month==7){
                if (day >= 2 && day <= 31){
                    date = day - 1;
                }
                else if (day == 1){
                    date = 30;
                }
                else{
                    passesValidation = false;
                }
            }
            else if (month==8){
                if (day >= 2 && day <= 31){
                    date = day - 1;
                }
                else if (day == 1){
                    date = 31;
                }
                else{
                    passesValidation = false;
                }
            }
            else if (month==9){
                if (day >= 2 && day <= 30){
                    date = day - 1;
                }
                else if (day == 1){
                    date = 31;
                }
                else{
                    passesValidation = false;
                }
            }
            else if (month==10){
                if (day >= 2 && day <= 31){
                    date = day - 1;
                }
                else if (day == 1){
                    date = 30;
                }
                else{
                    passesValidation = false;
                }
            }
            else if (month==11){
                if (day >= 2 && day <= 30){
                    date = day - 1;
                }
                else if (day == 1){
                    date = 31;
                }
                else{
                    passesValidation = false;
                }
            }
            else if (month==12){
                if (day >= 2 && day <= 31){
                    date = day - 1;
                }
                else if (day == 1){
                    date = 30;
                }
                else{
                    passesValidation = false;
                }
            }
            else{
                passesValidation = false;
            }
            //System.out.print(" "+date);
        }
        if (passesValidation){
            if (year<0 || year>2099){
                System.out.println("Invalid year: " + year);
                passesValidation = false;
            }
            /*else{
                System.out.println(", "+year);
            }*/
        }
        if (passesValidation){
            System.out.println(monthName + " " + date + ", " + year);
        }
    }
}
